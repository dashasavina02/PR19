﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ПР19
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void учет_изделий__собранных_в_цехе_за_неделюBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.учет_изделий__собранных_в_цехе_за_неделюBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this._Учет_изделий__собранных_в_цехе_за_неделюDataSet);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_Учет_изделий__собранных_в_цехе_за_неделюDataSet._Учет_изделий__собранных_в_цехе_за_неделю". При необходимости она может быть перемещена или удалена.
            this.учет_изделий__собранных_в_цехе_за_неделюTableAdapter.Fill(this._Учет_изделий__собранных_в_цехе_за_неделюDataSet._Учет_изделий__собранных_в_цехе_за_неделю);

        }
        //Кнопка удалить
        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult rezult;
            rezult = MessageBox.Show("Удаление записи", "Подтвердите удаление записи", MessageBoxButtons.YesNo);
            if (rezult == DialogResult.Yes)
            {
                //Удаляем текущую запись
                учет_изделий__собранных_в_цехе_за_неделюBindingSource.RemoveCurrent();
                //Сохраняем изменения в БД
                учет_изделий__собранных_в_цехе_за_неделюTableAdapter.Update(this._Учет_изделий__собранных_в_цехе_за_неделюDataSet._Учет_изделий__собранных_в_цехе_за_неделю);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        //Кнопка Добавить
        private void button1_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.ShowDialog();
            //Запоминаем текущую позицию
            int row, col;
            row = учет_изделий__собранных_в_цехе_за_неделюDataGridView.CurrentCell.RowIndex;
            col = учет_изделий__собранных_в_цехе_за_неделюDataGridView.CurrentCell.ColumnIndex;
            //Перечитываем таблицу
            this.учет_изделий__собранных_в_цехе_за_неделюTableAdapter.Fill(this._Учет_изделий__собранных_в_цехе_за_неделюDataSet._Учет_изделий__собранных_в_цехе_за_неделю);
            //Перемещаем указатель в текущую позицию
            учет_изделий__собранных_в_цехе_за_неделюDataGridView.CurrentCell = учет_изделий__собранных_в_цехе_за_неделюDataGridView[col, row];
        }

        //Кнопка Поиска
        private void button3_Click(object sender, EventArgs e)
        {
            string NameField;//Поле для поиска
            NameField = "Стоимость";
            int Index;//Номер строки
            //Ищем элемент в заданном поле БД и запоминаем номер строки
            //с найденным элементом, если элемента нет то будет -1
            Index = учет_изделий__собранных_в_цехе_за_неделюBindingSource.Find(NameField, textBox2.Text);
            //При успешном поиске перемещается на строку с полученным номером
            if (Index > -1) учет_изделий__собранных_в_цехе_за_неделюBindingSource.Position = Index;
            else MessageBox.Show("Поиск завершен. Образец не найден");
        }
    }
}


