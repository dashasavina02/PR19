﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ПР19
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void учет_изделий__собранных_в_цехе_за_неделюBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.учет_изделий__собранных_в_цехе_за_неделюBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this._Учет_изделий__собранных_в_цехе_за_неделюDataSet);

        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_Учет_изделий__собранных_в_цехе_за_неделюDataSet._Учет_изделий__собранных_в_цехе_за_неделю". При необходимости она может быть перемещена или удалена.
            this.учет_изделий__собранных_в_цехе_за_неделюTableAdapter.Fill(this._Учет_изделий__собранных_в_цехе_за_неделюDataSet._Учет_изделий__собранных_в_цехе_за_неделю);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Примеры проверки полей
            if (фамилияTextBox.Text.Length == 0 || имяTextBox.Text.Length == 0 || отчество_сботщикаTextBox.Text.Length == 0 || название_цехаTextBox.Text.Length == 0 || тип_изделияTextBox.Text.Length == 0 || стоимостьTextBox.Text.Length == 0)
            {
                MessageBox.Show("Заполните все поля"); return;
            }
            this.Validate();
            this.учет_изделий__собранных_в_цехе_за_неделюBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this._Учет_изделий__собранных_в_цехе_за_неделюDataSet);
            Close();
        }
    }
}
