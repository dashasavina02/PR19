﻿namespace ПР19
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            System.Windows.Forms.Label фамилияLabel;
            System.Windows.Forms.Label имяLabel;
            System.Windows.Forms.Label отчество_сботщикаLabel;
            System.Windows.Forms.Label понедельникLabel;
            System.Windows.Forms.Label вторникLabel;
            System.Windows.Forms.Label средаLabel;
            System.Windows.Forms.Label четвергLabel;
            System.Windows.Forms.Label пятницаLabel;
            System.Windows.Forms.Label субботаLabel;
            System.Windows.Forms.Label воскресеньеLabel;
            System.Windows.Forms.Label название_цехаLabel;
            System.Windows.Forms.Label тип_изделияLabel;
            System.Windows.Forms.Label стоимостьLabel;
            this._Учет_изделий__собранных_в_цехе_за_неделюDataSet = new ПР19._Учет_изделий__собранных_в_цехе_за_неделюDataSet();
            this.учет_изделий__собранных_в_цехе_за_неделюBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.учет_изделий__собранных_в_цехе_за_неделюTableAdapter = new ПР19._Учет_изделий__собранных_в_цехе_за_неделюDataSetTableAdapters.Учет_изделий__собранных_в_цехе_за_неделюTableAdapter();
            this.tableAdapterManager = new ПР19._Учет_изделий__собранных_в_цехе_за_неделюDataSetTableAdapters.TableAdapterManager();
            this.учет_изделий__собранных_в_цехе_за_неделюBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.учет_изделий__собранных_в_цехе_за_неделюBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.фамилияTextBox = new System.Windows.Forms.TextBox();
            this.имяTextBox = new System.Windows.Forms.TextBox();
            this.отчество_сботщикаTextBox = new System.Windows.Forms.TextBox();
            this.понедельникTextBox = new System.Windows.Forms.TextBox();
            this.вторникTextBox = new System.Windows.Forms.TextBox();
            this.средаTextBox = new System.Windows.Forms.TextBox();
            this.четвергTextBox = new System.Windows.Forms.TextBox();
            this.пятницаTextBox = new System.Windows.Forms.TextBox();
            this.субботаTextBox = new System.Windows.Forms.TextBox();
            this.воскресеньеTextBox = new System.Windows.Forms.TextBox();
            this.название_цехаTextBox = new System.Windows.Forms.TextBox();
            this.тип_изделияTextBox = new System.Windows.Forms.TextBox();
            this.стоимостьTextBox = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            фамилияLabel = new System.Windows.Forms.Label();
            имяLabel = new System.Windows.Forms.Label();
            отчество_сботщикаLabel = new System.Windows.Forms.Label();
            понедельникLabel = new System.Windows.Forms.Label();
            вторникLabel = new System.Windows.Forms.Label();
            средаLabel = new System.Windows.Forms.Label();
            четвергLabel = new System.Windows.Forms.Label();
            пятницаLabel = new System.Windows.Forms.Label();
            субботаLabel = new System.Windows.Forms.Label();
            воскресеньеLabel = new System.Windows.Forms.Label();
            название_цехаLabel = new System.Windows.Forms.Label();
            тип_изделияLabel = new System.Windows.Forms.Label();
            стоимостьLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this._Учет_изделий__собранных_в_цехе_за_неделюDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.учет_изделий__собранных_в_цехе_за_неделюBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.учет_изделий__собранных_в_цехе_за_неделюBindingNavigator)).BeginInit();
            this.учет_изделий__собранных_в_цехе_за_неделюBindingNavigator.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // _Учет_изделий__собранных_в_цехе_за_неделюDataSet
            // 
            this._Учет_изделий__собранных_в_цехе_за_неделюDataSet.DataSetName = "_Учет_изделий__собранных_в_цехе_за_неделюDataSet";
            this._Учет_изделий__собранных_в_цехе_за_неделюDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // учет_изделий__собранных_в_цехе_за_неделюBindingSource
            // 
            this.учет_изделий__собранных_в_цехе_за_неделюBindingSource.DataMember = "Учет изделий, собранных в цехе за неделю";
            this.учет_изделий__собранных_в_цехе_за_неделюBindingSource.DataSource = this._Учет_изделий__собранных_в_цехе_за_неделюDataSet;
            // 
            // учет_изделий__собранных_в_цехе_за_неделюTableAdapter
            // 
            this.учет_изделий__собранных_в_цехе_за_неделюTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.UpdateOrder = ПР19._Учет_изделий__собранных_в_цехе_за_неделюDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.Учет_изделий__собранных_в_цехе_за_неделюTableAdapter = this.учет_изделий__собранных_в_цехе_за_неделюTableAdapter;
            // 
            // учет_изделий__собранных_в_цехе_за_неделюBindingNavigator
            // 
            this.учет_изделий__собранных_в_цехе_за_неделюBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.учет_изделий__собранных_в_цехе_за_неделюBindingNavigator.BindingSource = this.учет_изделий__собранных_в_цехе_за_неделюBindingSource;
            this.учет_изделий__собранных_в_цехе_за_неделюBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.учет_изделий__собранных_в_цехе_за_неделюBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.учет_изделий__собранных_в_цехе_за_неделюBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.учет_изделий__собранных_в_цехе_за_неделюBindingNavigatorSaveItem});
            this.учет_изделий__собранных_в_цехе_за_неделюBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.учет_изделий__собранных_в_цехе_за_неделюBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.учет_изделий__собранных_в_цехе_за_неделюBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.учет_изделий__собранных_в_цехе_за_неделюBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.учет_изделий__собранных_в_цехе_за_неделюBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.учет_изделий__собранных_в_цехе_за_неделюBindingNavigator.Name = "учет_изделий__собранных_в_цехе_за_неделюBindingNavigator";
            this.учет_изделий__собранных_в_цехе_за_неделюBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.учет_изделий__собранных_в_цехе_за_неделюBindingNavigator.Size = new System.Drawing.Size(494, 25);
            this.учет_изделий__собранных_в_цехе_за_неделюBindingNavigator.TabIndex = 0;
            this.учет_изделий__собранных_в_цехе_за_неделюBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(43, 15);
            this.bindingNavigatorCountItem.Text = "для {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorMoveNextItem.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorMoveLastItem.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Добавить";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorDeleteItem.Text = "Удалить";
            // 
            // учет_изделий__собранных_в_цехе_за_неделюBindingNavigatorSaveItem
            // 
            this.учет_изделий__собранных_в_цехе_за_неделюBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.учет_изделий__собранных_в_цехе_за_неделюBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("учет_изделий__собранных_в_цехе_за_неделюBindingNavigatorSaveItem.Image")));
            this.учет_изделий__собранных_в_цехе_за_неделюBindingNavigatorSaveItem.Name = "учет_изделий__собранных_в_цехе_за_неделюBindingNavigatorSaveItem";
            this.учет_изделий__собранных_в_цехе_за_неделюBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 23);
            this.учет_изделий__собранных_в_цехе_за_неделюBindingNavigatorSaveItem.Text = "Сохранить данные";
            this.учет_изделий__собранных_в_цехе_за_неделюBindingNavigatorSaveItem.Click += new System.EventHandler(this.учет_изделий__собранных_в_цехе_за_неделюBindingNavigatorSaveItem_Click);
            // 
            // фамилияLabel
            // 
            фамилияLabel.AutoSize = true;
            фамилияLabel.Location = new System.Drawing.Point(56, 19);
            фамилияLabel.Name = "фамилияLabel";
            фамилияLabel.Size = new System.Drawing.Size(59, 13);
            фамилияLabel.TabIndex = 1;
            фамилияLabel.Text = "Фамилия:";
            // 
            // фамилияTextBox
            // 
            this.фамилияTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.учет_изделий__собранных_в_цехе_за_неделюBindingSource, "Фамилия", true));
            this.фамилияTextBox.Location = new System.Drawing.Point(121, 16);
            this.фамилияTextBox.Name = "фамилияTextBox";
            this.фамилияTextBox.Size = new System.Drawing.Size(100, 20);
            this.фамилияTextBox.TabIndex = 2;
            // 
            // имяLabel
            // 
            имяLabel.AutoSize = true;
            имяLabel.Location = new System.Drawing.Point(83, 41);
            имяLabel.Name = "имяLabel";
            имяLabel.Size = new System.Drawing.Size(32, 13);
            имяLabel.TabIndex = 3;
            имяLabel.Text = "Имя:";
            // 
            // имяTextBox
            // 
            this.имяTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.учет_изделий__собранных_в_цехе_за_неделюBindingSource, "Имя", true));
            this.имяTextBox.Location = new System.Drawing.Point(121, 38);
            this.имяTextBox.Name = "имяTextBox";
            this.имяTextBox.Size = new System.Drawing.Size(100, 20);
            this.имяTextBox.TabIndex = 4;
            // 
            // отчество_сботщикаLabel
            // 
            отчество_сботщикаLabel.AutoSize = true;
            отчество_сботщикаLabel.Location = new System.Drawing.Point(5, 63);
            отчество_сботщикаLabel.Name = "отчество_сботщикаLabel";
            отчество_сботщикаLabel.Size = new System.Drawing.Size(111, 13);
            отчество_сботщикаLabel.TabIndex = 5;
            отчество_сботщикаLabel.Text = "Отчество сборщика:";
            // 
            // отчество_сботщикаTextBox
            // 
            this.отчество_сботщикаTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.учет_изделий__собранных_в_цехе_за_неделюBindingSource, "Отчество сботщика", true));
            this.отчество_сботщикаTextBox.Location = new System.Drawing.Point(121, 60);
            this.отчество_сботщикаTextBox.Name = "отчество_сботщикаTextBox";
            this.отчество_сботщикаTextBox.Size = new System.Drawing.Size(100, 20);
            this.отчество_сботщикаTextBox.TabIndex = 6;
            // 
            // понедельникLabel
            // 
            понедельникLabel.AutoSize = true;
            понедельникLabel.Location = new System.Drawing.Point(22, 23);
            понедельникLabel.Name = "понедельникLabel";
            понедельникLabel.Size = new System.Drawing.Size(78, 13);
            понедельникLabel.TabIndex = 7;
            понедельникLabel.Text = "Понедельник:";
            // 
            // понедельникTextBox
            // 
            this.понедельникTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.учет_изделий__собранных_в_цехе_за_неделюBindingSource, "Понедельник", true));
            this.понедельникTextBox.Location = new System.Drawing.Point(106, 20);
            this.понедельникTextBox.Name = "понедельникTextBox";
            this.понедельникTextBox.Size = new System.Drawing.Size(100, 20);
            this.понедельникTextBox.TabIndex = 8;
            // 
            // вторникLabel
            // 
            вторникLabel.AutoSize = true;
            вторникLabel.Location = new System.Drawing.Point(48, 49);
            вторникLabel.Name = "вторникLabel";
            вторникLabel.Size = new System.Drawing.Size(52, 13);
            вторникLabel.TabIndex = 9;
            вторникLabel.Text = "Вторник:";
            // 
            // вторникTextBox
            // 
            this.вторникTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.учет_изделий__собранных_в_цехе_за_неделюBindingSource, "Вторник", true));
            this.вторникTextBox.Location = new System.Drawing.Point(106, 46);
            this.вторникTextBox.Name = "вторникTextBox";
            this.вторникTextBox.Size = new System.Drawing.Size(100, 20);
            this.вторникTextBox.TabIndex = 10;
            // 
            // средаLabel
            // 
            средаLabel.AutoSize = true;
            средаLabel.Location = new System.Drawing.Point(59, 79);
            средаLabel.Name = "средаLabel";
            средаLabel.Size = new System.Drawing.Size(41, 13);
            средаLabel.TabIndex = 11;
            средаLabel.Text = "Среда:";
            // 
            // средаTextBox
            // 
            this.средаTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.учет_изделий__собранных_в_цехе_за_неделюBindingSource, "Среда", true));
            this.средаTextBox.Location = new System.Drawing.Point(106, 76);
            this.средаTextBox.Name = "средаTextBox";
            this.средаTextBox.Size = new System.Drawing.Size(100, 20);
            this.средаTextBox.TabIndex = 12;
            // 
            // четвергLabel
            // 
            четвергLabel.AutoSize = true;
            четвергLabel.Location = new System.Drawing.Point(48, 105);
            четвергLabel.Name = "четвергLabel";
            четвергLabel.Size = new System.Drawing.Size(52, 13);
            четвергLabel.TabIndex = 13;
            четвергLabel.Text = "Четверг:";
            // 
            // четвергTextBox
            // 
            this.четвергTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.учет_изделий__собранных_в_цехе_за_неделюBindingSource, "Четверг", true));
            this.четвергTextBox.Location = new System.Drawing.Point(106, 102);
            this.четвергTextBox.Name = "четвергTextBox";
            this.четвергTextBox.Size = new System.Drawing.Size(100, 20);
            this.четвергTextBox.TabIndex = 14;
            // 
            // пятницаLabel
            // 
            пятницаLabel.AutoSize = true;
            пятницаLabel.Location = new System.Drawing.Point(47, 131);
            пятницаLabel.Name = "пятницаLabel";
            пятницаLabel.Size = new System.Drawing.Size(53, 13);
            пятницаLabel.TabIndex = 15;
            пятницаLabel.Text = "Пятница:";
            // 
            // пятницаTextBox
            // 
            this.пятницаTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.учет_изделий__собранных_в_цехе_за_неделюBindingSource, "Пятница", true));
            this.пятницаTextBox.Location = new System.Drawing.Point(106, 128);
            this.пятницаTextBox.Name = "пятницаTextBox";
            this.пятницаTextBox.Size = new System.Drawing.Size(100, 20);
            this.пятницаTextBox.TabIndex = 16;
            // 
            // субботаLabel
            // 
            субботаLabel.AutoSize = true;
            субботаLabel.Location = new System.Drawing.Point(49, 157);
            субботаLabel.Name = "субботаLabel";
            субботаLabel.Size = new System.Drawing.Size(51, 13);
            субботаLabel.TabIndex = 17;
            субботаLabel.Text = "Суббота:";
            // 
            // субботаTextBox
            // 
            this.субботаTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.учет_изделий__собранных_в_цехе_за_неделюBindingSource, "Суббота", true));
            this.субботаTextBox.Location = new System.Drawing.Point(106, 154);
            this.субботаTextBox.Name = "субботаTextBox";
            this.субботаTextBox.Size = new System.Drawing.Size(100, 20);
            this.субботаTextBox.TabIndex = 18;
            // 
            // воскресеньеLabel
            // 
            воскресеньеLabel.AutoSize = true;
            воскресеньеLabel.Location = new System.Drawing.Point(23, 183);
            воскресеньеLabel.Name = "воскресеньеLabel";
            воскресеньеLabel.Size = new System.Drawing.Size(77, 13);
            воскресеньеLabel.TabIndex = 19;
            воскресеньеLabel.Text = "Воскресенье:";
            // 
            // воскресеньеTextBox
            // 
            this.воскресеньеTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.учет_изделий__собранных_в_цехе_за_неделюBindingSource, "Воскресенье", true));
            this.воскресеньеTextBox.Location = new System.Drawing.Point(106, 180);
            this.воскресеньеTextBox.Name = "воскресеньеTextBox";
            this.воскресеньеTextBox.Size = new System.Drawing.Size(100, 20);
            this.воскресеньеTextBox.TabIndex = 20;
            // 
            // название_цехаLabel
            // 
            название_цехаLabel.AutoSize = true;
            название_цехаLabel.Location = new System.Drawing.Point(18, 18);
            название_цехаLabel.Name = "название_цехаLabel";
            название_цехаLabel.Size = new System.Drawing.Size(86, 13);
            название_цехаLabel.TabIndex = 21;
            название_цехаLabel.Text = "Название цеха:";
            // 
            // название_цехаTextBox
            // 
            this.название_цехаTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.учет_изделий__собранных_в_цехе_за_неделюBindingSource, "Название цеха", true));
            this.название_цехаTextBox.Location = new System.Drawing.Point(110, 15);
            this.название_цехаTextBox.Name = "название_цехаTextBox";
            this.название_цехаTextBox.Size = new System.Drawing.Size(100, 20);
            this.название_цехаTextBox.TabIndex = 22;
            // 
            // тип_изделияLabel
            // 
            тип_изделияLabel.AutoSize = true;
            тип_изделияLabel.Location = new System.Drawing.Point(30, 44);
            тип_изделияLabel.Name = "тип_изделияLabel";
            тип_изделияLabel.Size = new System.Drawing.Size(74, 13);
            тип_изделияLabel.TabIndex = 23;
            тип_изделияLabel.Text = "Тип изделия:";
            // 
            // тип_изделияTextBox
            // 
            this.тип_изделияTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.учет_изделий__собранных_в_цехе_за_неделюBindingSource, "Тип изделия", true));
            this.тип_изделияTextBox.Location = new System.Drawing.Point(110, 41);
            this.тип_изделияTextBox.Name = "тип_изделияTextBox";
            this.тип_изделияTextBox.Size = new System.Drawing.Size(100, 20);
            this.тип_изделияTextBox.TabIndex = 24;
            // 
            // стоимостьLabel
            // 
            стоимостьLabel.AutoSize = true;
            стоимостьLabel.Location = new System.Drawing.Point(39, 70);
            стоимостьLabel.Name = "стоимостьLabel";
            стоимостьLabel.Size = new System.Drawing.Size(65, 13);
            стоимостьLabel.TabIndex = 25;
            стоимостьLabel.Text = "Стоимость:";
            // 
            // стоимостьTextBox
            // 
            this.стоимостьTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.учет_изделий__собранных_в_цехе_за_неделюBindingSource, "Стоимость", true));
            this.стоимостьTextBox.Location = new System.Drawing.Point(110, 67);
            this.стоимостьTextBox.Name = "стоимостьTextBox";
            this.стоимостьTextBox.Size = new System.Drawing.Size(100, 20);
            this.стоимостьTextBox.TabIndex = 26;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(отчество_сботщикаLabel);
            this.groupBox1.Controls.Add(this.отчество_сботщикаTextBox);
            this.groupBox1.Controls.Add(имяLabel);
            this.groupBox1.Controls.Add(this.имяTextBox);
            this.groupBox1.Controls.Add(фамилияLabel);
            this.groupBox1.Controls.Add(this.фамилияTextBox);
            this.groupBox1.Location = new System.Drawing.Point(9, 44);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(234, 89);
            this.groupBox1.TabIndex = 27;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Сборщик";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(стоимостьLabel);
            this.groupBox2.Controls.Add(this.стоимостьTextBox);
            this.groupBox2.Controls.Add(тип_изделияLabel);
            this.groupBox2.Controls.Add(this.тип_изделияTextBox);
            this.groupBox2.Controls.Add(название_цехаLabel);
            this.groupBox2.Controls.Add(this.название_цехаTextBox);
            this.groupBox2.Location = new System.Drawing.Point(21, 148);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(221, 96);
            this.groupBox2.TabIndex = 28;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Учет";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(воскресеньеLabel);
            this.groupBox3.Controls.Add(this.воскресеньеTextBox);
            this.groupBox3.Controls.Add(субботаLabel);
            this.groupBox3.Controls.Add(this.субботаTextBox);
            this.groupBox3.Controls.Add(пятницаLabel);
            this.groupBox3.Controls.Add(this.пятницаTextBox);
            this.groupBox3.Controls.Add(четвергLabel);
            this.groupBox3.Controls.Add(this.четвергTextBox);
            this.groupBox3.Controls.Add(средаLabel);
            this.groupBox3.Controls.Add(this.средаTextBox);
            this.groupBox3.Controls.Add(вторникLabel);
            this.groupBox3.Controls.Add(this.вторникTextBox);
            this.groupBox3.Controls.Add(понедельникLabel);
            this.groupBox3.Controls.Add(this.понедельникTextBox);
            this.groupBox3.Location = new System.Drawing.Point(270, 44);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(212, 200);
            this.groupBox3.TabIndex = 29;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Кол-во изделий в день";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(54, 263);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(154, 23);
            this.button1.TabIndex = 30;
            this.button1.Text = "OK";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(494, 295);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.учет_изделий__собранных_в_цехе_за_неделюBindingNavigator);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this._Учет_изделий__собранных_в_цехе_за_неделюDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.учет_изделий__собранных_в_цехе_за_неделюBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.учет_изделий__собранных_в_цехе_за_неделюBindingNavigator)).EndInit();
            this.учет_изделий__собранных_в_цехе_за_неделюBindingNavigator.ResumeLayout(false);
            this.учет_изделий__собранных_в_цехе_за_неделюBindingNavigator.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private _Учет_изделий__собранных_в_цехе_за_неделюDataSet _Учет_изделий__собранных_в_цехе_за_неделюDataSet;
        private System.Windows.Forms.BindingSource учет_изделий__собранных_в_цехе_за_неделюBindingSource;
        private _Учет_изделий__собранных_в_цехе_за_неделюDataSetTableAdapters.Учет_изделий__собранных_в_цехе_за_неделюTableAdapter учет_изделий__собранных_в_цехе_за_неделюTableAdapter;
        private _Учет_изделий__собранных_в_цехе_за_неделюDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator учет_изделий__собранных_в_цехе_за_неделюBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton учет_изделий__собранных_в_цехе_за_неделюBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox фамилияTextBox;
        private System.Windows.Forms.TextBox имяTextBox;
        private System.Windows.Forms.TextBox отчество_сботщикаTextBox;
        private System.Windows.Forms.TextBox понедельникTextBox;
        private System.Windows.Forms.TextBox вторникTextBox;
        private System.Windows.Forms.TextBox средаTextBox;
        private System.Windows.Forms.TextBox четвергTextBox;
        private System.Windows.Forms.TextBox пятницаTextBox;
        private System.Windows.Forms.TextBox субботаTextBox;
        private System.Windows.Forms.TextBox воскресеньеTextBox;
        private System.Windows.Forms.TextBox название_цехаTextBox;
        private System.Windows.Forms.TextBox тип_изделияTextBox;
        private System.Windows.Forms.TextBox стоимостьTextBox;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button button1;
    }
}